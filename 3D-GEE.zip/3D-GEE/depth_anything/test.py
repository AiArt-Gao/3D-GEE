import cv2
import torch
import torch.nn as nn
import numpy as np
from .depth_anything_v2.dpt import DepthAnythingV2
from torchvision.transforms import Compose
import torchvision.transforms as transforms
from .depth_anything_v2.util.transform import Resize, NormalizeImage, PrepareForNet
import torch.nn.functional as F
class cal_depth_loss():

    def __init__(self):
        model_configs = {
            'vits': {'encoder': 'vits', 'features': 64, 'out_channels': [48, 96, 192, 384]},
            'vitb': {'encoder': 'vitb', 'features': 128, 'out_channels': [96, 192, 384, 768]},
            'vitl': {'encoder': 'vitl', 'features': 256, 'out_channels': [256, 512, 1024, 1024]},
            'vitg': {'encoder': 'vitg', 'features': 384, 'out_channels': [1536, 1536, 1536, 1536]}
        }

        encoder = 'vitl' # or 'vits', 'vitb', 'vitg'

        self.device = 'cuda'
        self.model = DepthAnythingV2(**model_configs[encoder])
        self.model.load_state_dict(torch.load('/home/yifan/yf/Depth-Anything-V2-main/depth_anything_v2_vitl.pth'))
        self.model.cuda()
        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=0.000005, betas=(0.9, 0.999))
        self.criterionGeom = torch.nn.BCELoss(reduce=True)
        self.depthloss = torch.tensor(0., device=self.device)
        self.depthloss2 = torch.tensor(0., device=self.device)
        self.normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                         std=[0.229, 0.224, 0.225])
    def cal_loss(self,inputA,inputB):

        # inputA_in = inputA.clone().detach().requires_grad_(True)
        # inputB_in = inputB.clone().detach()
        #
        # inputA_in = F.interpolate(inputA_in, (266, 266), mode="bilinear", align_corners=True)
        # inputA_in = (inputA_in - inputA_in.min()) / (inputA_in.max() - inputA_in.min())
        #
        # inputA_in = self.normalize(inputA_in)
        # depthA_in = self.model.infer_image(inputA_in)  # HxW raw depth map in numpy
        # depthA_in = (depthA_in - depthA_in.min()) / (depthA_in.max() - depthA_in.min())
        # with torch.no_grad():
        #     inputB_in = F.interpolate(inputB_in, (266, 266), mode="bilinear", align_corners=True)
        #     inputB_in = (inputB_in - inputB_in.min()) / (inputB_in.max() - inputB_in.min())
        #     inputB_in = self.normalize(inputB_in)
        #     depthB_in = self.model.infer_image(inputB_in)  # HxW raw depth map in numpy
        #     depthB_in = (depthB_in - depthB_in.min()) / (depthB_in.max() - depthB_in.min())



        with torch.no_grad():
            inputA = F.interpolate(inputA, (266, 266), mode="bilinear", align_corners=True)
            inputA = (inputA - inputA.min()) / (inputA.max() - inputA.min())


            inputA = self.normalize(inputA)
            depthA = self.model.infer_image(inputA) # HxW raw depth map in numpy
            depthA = (depthA - depthA.min()) / (depthA.max() - depthA.min())


            inputB = F.interpolate(inputB.detach(), (266, 266), mode="bilinear", align_corners=True)
            inputB = (inputB - inputB.min()) / (inputB.max() - inputB.min())
            inputB = self.normalize(inputB)

            depthB = self.model.infer_image(inputB)  # HxW raw depth map in numpy
            depthB = (depthB - depthB.min()) / (depthB.max() - depthB.min())


        self.depthloss = self.criterionGeom(depthA, depthB)
        # self.depthloss2 = self.criterionGeom(depthA_in, depthB_in)

        # self.optimizer.zero_grad()
        # self.depthloss2.backward()
        # self.optimizer.step()

        return depthA,depthB,self.depthloss
