import torch

def Create_patch_feature(depth_map, patch_size):
    h , w =  depth_map.shape[1:3]

    assert h % patch_size == 0
    # 计算可以分割成几个patch
    num_patches_h = h // patch_size
    num_patches_w = w // patch_size
    patch_es = []
    patch_coordinates = []
    for i in range(num_patches_h):
        for j in range(num_patches_w):
            # 提取当前的patch
            patch = depth_map[ : ,i * patch_size: (i + 1) * patch_size,
                    j * patch_size: (j + 1) * patch_size]

            patch_es.append(patch.unsqueeze(1))
            # 记录左上角的坐标

            coord = torch.FloatTensor([i * patch_size, j * patch_size]).cuda()
            coord = coord.unsqueeze(0)
            coord = torch.cat([coord,coord,coord,coord],0)
            patch_coordinates.append(coord.unsqueeze(1))
    patch_coordinates = torch.cat(patch_coordinates,dim=1)
    patch_es = torch.cat(patch_es,dim=1)
    return patch_es, patch_coordinates


if __name__ == '__main__':
    x = torch.rand((4,256,256)).to(1)
    a,b  = Create_patch_feature(x,8)
    print(len(a))
    print(a.shape)
    print(len(b))
    print(b.shape)